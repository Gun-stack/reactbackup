package com.kosta.catdog;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatdogApplicationTests {
	
}
