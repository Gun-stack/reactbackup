package com.kosta.catdog.service;

import org.springframework.stereotype.Service;

@Service
public class Constants {
	public static final String ACTIVATION_EMAIL = "/activate";
}
