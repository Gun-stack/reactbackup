package com.kosta.catdog.repository;


import com.kosta.catdog.entity.DesFileVo;
import com.kosta.catdog.entity.ShopFileVO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DesFileVORepository extends JpaRepository<DesFileVo, Integer> {


}
