package com.kosta.catdog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kosta.catdog.entity.DesGalleryLike;

public interface DesGalleryLikeRepository extends JpaRepository<DesGalleryLike, Integer> {
	
}
